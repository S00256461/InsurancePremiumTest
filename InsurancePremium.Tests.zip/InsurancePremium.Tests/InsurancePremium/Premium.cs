﻿using System;

namespace InsurancePremium
{
    public interface IDiscountService
    {
        double GetDiscount();
    }

    public class InsuranceService
    {
        private readonly IDiscountService _discountService;

        public InsuranceService(IDiscountService discountService)
        {
            _discountService = discountService;
        }

        public double CalcPremium(int age, string gameMode)
        {
            double premium;

            if (gameMode == "casual")
            {
                if (age >= 18 && age <= 30)
                    premium = 5.0;
                else if (age >= 31)
                    premium = 3.50;
                else
                    premium = 0.0;
            }
            else if (gameMode == "hardcore")
            {
                if (age >= 18 && age <= 35)
                    premium = 6.0;
                else if (age >= 36)
                    premium = 5.0;
                else
                    premium = 0.0;
            }
            else
            {
                premium = 0.0;
            }

            if (age >= 50)
            {
                double discount = _discountService.GetDiscount();
                premium *= discount;
            }

            return premium;
        }
    }

    
    class Program
    {
        static void Main()
        {
            
            IDiscountService discountService = new TestDiscountService();
            var service = new InsuranceService(discountService);

            Console.WriteLine("Enter your age:");
            int age = int.Parse(Console.ReadLine());

            Console.WriteLine("choose (casual или hardcore):");
            string gameMode = Console.ReadLine();

            double premium = service.CalcPremium(age, gameMode);
            Console.WriteLine($"insurance premium: {premium} euro");
        }
    }

    
    public class TestDiscountService : IDiscountService
    {
        public double GetDiscount()
        {
            return 0.9; // 10% discount
        }
    }
}
