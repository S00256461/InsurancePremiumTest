using NUnit.Framework;
using Moq;

namespace InsurancePremium.Tests.Tests
{
    [TestFixture]
    public class InsuranceServiceTests
    {
        [Test]
        public void Test_Casual_Age18To30()
        {
            var mock = new Mock<IDiscountService>();
            mock.Setup(d => d.GetDiscount()).Returns(1.0);
            var service = new InsuranceService(mock.Object);

            double result = service.CalcPremium(25, "casual");
            Assert.That(result, Is.EqualTo(5.0));
        }

        [Test]
        public void Test_Casual_Age31AndAbove()
        {
            var mock = new Mock<IDiscountService>();
            mock.Setup(d => d.GetDiscount()).Returns(1.0);
            var service = new InsuranceService(mock.Object);

            double result = service.CalcPremium(35, "casual");
            Assert.That(result, Is.EqualTo(3.5));
        }

        [Test]
        public void Test_Hardcore_Age36()
        {
            var mock = new Mock<IDiscountService>();
            mock.Setup(d => d.GetDiscount()).Returns(1.0);
            var service = new InsuranceService(mock.Object);

            double result = service.CalcPremium(36, "hardcore");
            Assert.That(result, Is.EqualTo(5.0));
        }

        [Test]
        public void Test_Discount_Age50()
        {
            var mock = new Mock<IDiscountService>();
            mock.Setup(d => d.GetDiscount()).Returns(0.8);
            var service = new InsuranceService(mock.Object);

            double result = service.CalcPremium(50, "casual");
            Assert.That(result, Is.EqualTo(4.0)); // 5.0 * 0.8
        }
    }
}

